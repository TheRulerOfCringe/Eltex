#!/bin/bash

# Проверка имени скрипта
script_name=$(basename "$0")
if [ "$script_name" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

# Создание имени лог-файла
log_file="report_${script_name%.*}.log"

# Запись начала работы
echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> "$log_file"

# Генерация случайного числа от 30 до 1800
sleep_time=$(( RANDOM % 1771 + 30 ))

# Ожидание
sleep "$sleep_time"

# Расчет минут работы
minutes=$(( sleep_time / 60 ))

# Запись завершения работы
echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $minutes минут" >> "$log_file"
