#!/bin/bash

config_file="observer.conf"
log_file="observer.log"

# Проверяем наличие файла конфигурации
if [ ! -f "$config_file" ]; then
    echo "$(date): Файл конфигурации $config_file не найден" >> "$log_file"
    exit 1
fi

# Читаем файл конфигурации построчно
while IFS= read -r script; do
    # Пропускаем пустые строки и комментарии
    [[ -z "$script" || "$script" =~ ^# ]] && continue
    
    # Проверяем наличие процесса
    if ! pgrep -f "$script" > /dev/null; then
        echo "$(date): Скрипт $script не найден, запускаем..." >> "$log_file"
        nohup bash "$script" > /dev/null 2>&1 &
        echo "$(date): Скрипт $script запущен с PID $!" >> "$log_file"
    fi
done < "$config_file"
